import React from "react";
import Table from "./table";




function App() {
  return (
    <Table></Table>
  );
}

export default App;
