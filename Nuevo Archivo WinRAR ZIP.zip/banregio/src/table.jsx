import React from "react";

const Table = () => {
  const data = [
    {
      number: "00103228",
      id: 1,
      date: "10/01/2021",
      monto: 37500,
      pending: true,
    },
    {
      number: "00103228",
      id: 2,
      date: "19/01/2021",
      monto: 725,
      pending: true,
    },
    {
      number: "00103228",
      id: 3,
      date: "31/01/2021",
      monto: 1578,
      pending: true,
    },
    {
      number: "00103228",
      id: 4,
      date: "04/01/2021",
      monto: 380,
      pending: true,
    },
  ];
  const plazo = (f1) => {
    const f2 = "15/02/2021";
    const aFecha1 = f1.split("/");
    console.log(aFecha1);
    const aFecha2 = f2.split("/");
    const fFecha1 = Date.UTC(aFecha1[2], aFecha1[1] - 1, aFecha1[0]);
    const fFecha2 = Date.UTC(aFecha2[2], aFecha2[1] - 1, aFecha2[0]);
    const dif = fFecha2 - fFecha1;
    const dias = Math.floor(dif / (1000 * 60 * 60 * 24));
    return dias;
    // const dateToday= new Date('05/02/2022')
    // return dateToday.getTime()-date1.getTime()
  };
  const interes = (monto, plazo) => {
    const iva = 1.16;
    const dias = 360;
    const interes = (monto * plazo * iva) / dias;
    return interes;
  };

  const pago =(monto, interes)=>{
      const pay =(monto+interes )*1.16
    return pay
  }

  return (
    <div>
      <table className="table">
        <tr>
          <th className="col">cliente</th>
          <th className="col">plazo</th>
          <th className="col">taza</th>
          <th className="col">monto</th>
          <th className="col">interes</th>
          <th className="col">IVA</th>
          <th className="col">pago</th>
        </tr>
        {data.map((client, i) => (
          <tr key={i}>
            <td className="col">{client.number}</td>
            <td className="col">{plazo(client.date)}</td>
            <td className="col">7%</td>
            <td className="col">{client.monto}</td>
            <td className="col">{interes(client.monto, plazo(client.date))}</td>
            <td className="col">
              {() => {
                interes(client.monto * 1.16);
              }}
            </td>
            <td className="col">16%</td>
            <td className="col">
              {pago(client.monto, interes(client.monto,plazo(client.date)))}
            </td>

            <td></td>
          </tr>
        ))}
      </table>
    </div>
  );
};

export default Table;
// {client.client.ids.date.getTime()-dateToday.getTime()}
